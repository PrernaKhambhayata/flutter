import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1419qkc (19:442)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupubfqNVe (PDdBh8ZHyRcDxG9QSiUbfq)
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdowntyn (30:106)
                    left: 0*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-Y4Y.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodZq2 (31:20)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup3jkmT9i (PDdBrTd5kpWgQW1wqf3JKM)
              padding: EdgeInsets.fromLTRB(52*fem, 45*fem, 52*fem, 173*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // image39oE (19:605)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 22*fem),
                    width: 163*fem,
                    height: 160*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-3.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // door4vC (19:607)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 44*fem),
                    child: Text(
                      'DOOR',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff934c18),
                      ),
                    ),
                  ),
                  Container(
                    // boxworkNvt (19:609)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 216*fem, 24*fem),
                    child: Text(
                      'Box work',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff472913),
                      ),
                    ),
                  ),
                  Container(
                    // length6mUyv (19:610)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 195*fem, 24*fem),
                    child: Text(
                      'Length : 6m',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff472913),
                      ),
                    ),
                  ),
                  Container(
                    // breath2mCf2 (19:611)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 194*fem, 24*fem),
                    child: Text(
                      'Breath : 2 m',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff472913),
                      ),
                    ),
                  ),
                  Container(
                    // materialofwoodwoodXBW (19:612)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 103*fem, 24*fem),
                    child: Text(
                      'Material of wood : wood',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff472913),
                      ),
                    ),
                  ),
                  Container(
                    // totalprice1200qT6 (19:613)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 138*fem, 0*fem),
                    child: Text(
                      'Total Price : 12,00/-',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff472913),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8k4G (19:600)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorddr (19:602)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-qK6.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorYF2 (19:604)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    width: 42.3*fem,
                    height: 43.7*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-Mrg.png',
                      width: 42.3*fem,
                      height: 43.7*fem,
                    ),
                  ),
                  Container(
                    // vectorrFi (19:603)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-g5W.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}