import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1414E2L (15:39)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupam9uLbA (PDd9WCCoW61sj5YBXVAM9u)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdown2it (30:94)
                    left: 0.0001220703*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-w3e.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodHep (31:15)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // manishawDa (19:451)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 24*fem),
              child: Text(
                'MANISHA',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff934c18),
                ),
              ),
            ),
            Container(
              // group12cac (19:473)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
              width: 353*fem,
              height: 47*fem,
              child: Image.asset(
                'assets/page-1/images/group-12.png',
                width: 353*fem,
                height: 47*fem,
              ),
            ),
            Container(
              // autogrouptrsm71a (PDd9eSU4bWvTTx7yvMTrsM)
              padding: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 86*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group9dEp (30:178)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 180*fem),
                    padding: EdgeInsets.fromLTRB(31.5*fem, 20*fem, 41*fem, 9*fem),
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // W3i (30:182)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.5*fem, 45*fem),
                          child: Text(
                            '1)',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupri8sBvY (PDd9tbj8qXWWL8pSrrRi8s)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 68.79*fem, 14*fem),
                          width: 161.21*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // date2472023h8C (30:181)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                width: double.infinity,
                                child: Text(
                                  'Date : 24/7/2023',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Text(
                                // time4houry5i (30:180)
                                'Time : 4 hour',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // UYG (30:183)
                          margin: EdgeInsets.fromLTRB(0*fem, 50*fem, 0*fem, 0*fem),
                          child: Text(
                            '500/-',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group18mXN (160:3)
                    margin: EdgeInsets.fromLTRB(92*fem, 0*fem, 84*fem, 33*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Add ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group1aUp (19:469)
                    margin: EdgeInsets.fromLTRB(92*fem, 0*fem, 84*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Calculate Bill',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8yG4 (19:446)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorFjN (19:448)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-R3v.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorKjE (19:450)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    width: 42.3*fem,
                    height: 43.7*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-yjn.png',
                      width: 42.3*fem,
                      height: 43.7*fem,
                    ),
                  ),
                  Container(
                    // vectorRXN (19:449)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-kKr.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}