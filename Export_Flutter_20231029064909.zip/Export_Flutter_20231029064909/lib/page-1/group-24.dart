import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // group24Pd2 (86:3)
        width: double.infinity,
        height: 844*fem,
        child: Container(
          // iphone1424MJx (30:12)
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xff472913),
          ),
          child: Stack(
            children: [
              Positioned(
                // rectangle45kk (30:13)
                left: 53*fem,
                top: 81*fem,
                child: Align(
                  child: SizedBox(
                    width: 284*fem,
                    height: 681*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0x23ffdac0),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // group2oAx (30:24)
                left: 89*fem,
                top: 570*fem,
                child: Container(
                  width: 214*fem,
                  height: 60*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff934c18),
                    borderRadius: BorderRadius.circular(20*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'ગુજરાતી',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // tools2423826640e15077042532441 (30:14)
                left: 72*fem,
                top: 127*fem,
                child: Align(
                  child: SizedBox(
                    width: 253*fem,
                    height: 203*fem,
                    child: Image.asset(
                      'assets/page-1/images/tools-2423826640-e1507704253244-1-7dr.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                // handywoodhfe (30:15)
                left: 77.5*fem,
                top: 366*fem,
                child: Align(
                  child: SizedBox(
                    width: 236*fem,
                    height: 45*fem,
                    child: Text(
                      'HANDY WOOD',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Kavoon',
                        fontSize: 36*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.25*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // selectlanguagebm2 (30:17)
                left: 103.5*fem,
                top: 435*fem,
                child: Align(
                  child: SizedBox(
                    width: 190*fem,
                    height: 30*fem,
                    child: Text(
                      'Select Language',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // group1h3N (30:21)
                left: 92*fem,
                top: 487*fem,
                child: Container(
                  width: 214*fem,
                  height: 60*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff934c18),
                    borderRadius: BorderRadius.circular(20*fem),
                  ),
                  child: Center(
                    child: Text(
                      'English',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}