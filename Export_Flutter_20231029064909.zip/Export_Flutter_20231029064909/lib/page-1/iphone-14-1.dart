import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone141bCU (2:2)
        padding: EdgeInsets.fromLTRB(53*fem, 4*fem, 16*fem, 82*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff472913),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // gridiconsdropdownNkx (30:74)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.41*fem),
              width: 99*fem,
              height: 69.59*fem,
              child: Image.asset(
                'assets/page-1/images/gridicons-dropdown.png',
                width: 99*fem,
                height: 69.59*fem,
              ),
            ),
            Container(
              // autogrouppsn3qeY (PDcyFjnKD3CrAa59q9PsN3)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(19*fem, 46*fem, 12*fem, 190*fem),
              width: 284*fem,
              decoration: BoxDecoration (
                color: Color(0x23ffdac0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tools2423826640e15077042532441 (6:19)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
                    width: 253*fem,
                    height: 203*fem,
                    child: Image.asset(
                      'assets/page-1/images/tools-2423826640-e1507704253244-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // handywood1Be (6:17)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 32*fem),
                    child: Text(
                      'HANDY WOOD',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Kavoon',
                        fontSize: 36*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.25*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // craftyourdreamsinwoodG7a (6:18)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                    constraints: BoxConstraints (
                      maxWidth: 162*fem,
                    ),
                    child: Text(
                      'Craft Your Dreams in Wood!!',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Nothing You Could Do',
                        fontSize: 32*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.335*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}