import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1423ADv (32:19)
        width: double.infinity,
        height: 844*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // iphone1421hUk (32:20)
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xffffffff),
          ),
          child: Container(
            // iphone143SSL (32:21)
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration (
              color: Color(0xffffffff),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  // group4Nqn (32:22)
                  width: double.infinity,
                  height: 246*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // rectangle38a4 (32:23)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 390*fem,
                            height: 112*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                color: Color(0xff472913),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // tools2423826640e15077042532441 (32:24)
                        left: 69*fem,
                        top: 43*fem,
                        child: Align(
                          child: SizedBox(
                            width: 253*fem,
                            height: 203*fem,
                            child: Image.asset(
                              'assets/page-1/images/tools-2423826640-e1507704253244-1-Jhe.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  // autogroupcejpw1i (PDdTqLL1bGf8vh6avZCeJP)
                  padding: EdgeInsets.fromLTRB(56*fem, 96*fem, 52*fem, 109*fem),
                  width: double.infinity,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // group5Fo6 (32:25)
                        margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 20*fem),
                        width: 278*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // forgotpasswordNsi (32:26)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 40*fem),
                              constraints: BoxConstraints (
                                maxWidth: 164*fem,
                              ),
                              child: Text(
                                'Forgot Password?',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                            Container(
                              // autogroupg8zfTuA (PDdU1FDAMssNXpaunJg8zF)
                              width: double.infinity,
                              height: 43*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // group4QZW (32:27)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 278*fem,
                                      height: 43*fem,
                                      child: Align(
                                        // rectangle1wpL (32:28)
                                        alignment: Alignment.topCenter,
                                        child: SizedBox(
                                          width: double.infinity,
                                          height: 42*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              color: Color(0x3fffdac0),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // otp59r (32:30)
                                    left: 53*fem,
                                    top: 13*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 29*fem,
                                        height: 17*fem,
                                        child: Text(
                                          'OTP',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff472913),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // mdiemailoutlineZKv (32:34)
                                    left: 9*fem,
                                    top: 9*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/mdi-email-outline-sG4.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group6FyS (32:38)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 22*fem),
                        width: 278*fem,
                        height: 43*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // group4Bs6 (32:40)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 278*fem,
                                  height: 43*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-4-m7n.png',
                                    width: 278*fem,
                                    height: 43*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // resetpassword6z4 (32:43)
                              left: 53*fem,
                              top: 13*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 107*fem,
                                  height: 17*fem,
                                  child: Text(
                                    'Reset Password',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff472913),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group7zJk (108:2)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 44*fem),
                        width: 278*fem,
                        height: 43*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // group4Wnt (108:3)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 278*fem,
                                  height: 43*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-4.png',
                                    width: 278*fem,
                                    height: 43*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // confirmpasswordRex (108:8)
                              left: 53*fem,
                              top: 13*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 121*fem,
                                  height: 17*fem,
                                  child: Text(
                                    'Confirm Password',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff472913),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group4w7W (32:31)
                        margin: EdgeInsets.fromLTRB(33*fem, 0*fem, 35*fem, 0*fem),
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Reset',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
          );
  }
}