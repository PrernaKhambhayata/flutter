import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 2543;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // group23pkg (86:2)
        width: double.infinity,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouphyvbZiG (PDd1favxfWA1MkCSqiHyvB)
              padding: EdgeInsets.fromLTRB(0*fem, 44.25*fem, 40*fem, 0*fem),
              height: 893*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // iphone142GMn (6:8)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 43*fem, 0*fem),
                    width: 390*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group3N9v (6:42)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 65*fem),
                          width: double.infinity,
                          height: 244*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle3LW4 (6:9)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 390*fem,
                                    height: 112*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // tools2423826640e15077042532441 (6:10)
                                left: 72*fem,
                                top: 41*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 253*fem,
                                    height: 203*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/tools-2423826640-e1507704253244-1-9e8.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // handywoodjo6 (6:13)
                          margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 0*fem, 7*fem),
                          child: Text(
                            'HANDY WOOD',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // craftyourdreamsinwoodEUx (6:14)
                          'Craft Your Dreams in Wood!!',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff934c18),
                          ),
                        ),
                        Container(
                          // autogroup1oek968 (PDd1xF7sRHCY2KFhUY1oeK)
                          padding: EdgeInsets.fromLTRB(60*fem, 50*fem, 52*fem, 58.75*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group2rmE (6:25)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupn563y5A (PDd2ApbFGa6ccezTshN563)
                                      padding: EdgeInsets.fromLTRB(7*fem, 3*fem, 156*fem, 5*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // mdiuser58C (6:29)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                            width: 34*fem,
                                            height: 34*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/mdi-user-moN.png',
                                              width: 34*fem,
                                              height: 34*fem,
                                            ),
                                          ),
                                          Container(
                                            // usernameyjN (6:38)
                                            margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                            child: Text(
                                              'Username',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // line1UAL (6:20)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                                      width: double.infinity,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff934c18),
                                      ),
                                    ),
                                    Container(
                                      // autogroupequ11AG (PDd2GKS5zrhfmuNzocEQu1)
                                      padding: EdgeInsets.fromLTRB(8.21*fem, 10*fem, 159*fem, 12.05*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // pheyelightWMv (6:35)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17.21*fem, 0*fem),
                                            width: 28.58*fem,
                                            height: 19.95*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/ph-eye-light-Qec.png',
                                              width: 28.58*fem,
                                              height: 19.95*fem,
                                            ),
                                          ),
                                          Container(
                                            // passwordCkY (6:39)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.95*fem),
                                            child: Text(
                                              'Password\n',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // forgotpasswordWFS (6:26)
                                margin: EdgeInsets.fromLTRB(170*fem, 0*fem, 0*fem, 63*fem),
                                child: Text(
                                  'Forgot Password!',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff934c18),
                                  ),
                                ),
                              ),
                              Container(
                                // group1R7W (6:24)
                                margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 32*fem, 80*fem),
                                width: double.infinity,
                                height: 60*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(20*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'LOGIN',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // donthaveanaccountsignupU5n (6:28)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Don’t have an account? ',
                                      ),
                                      TextSpan(
                                        text: 'Sign Up',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff934c18),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // iphone143iXr (6:40)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40*fem, 0*fem),
                    width: 390*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group4DzQ (6:43)
                          width: double.infinity,
                          height: 246*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle3NsJ (6:44)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 390*fem,
                                    height: 112*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // tools2423826640e15077042532441 (6:45)
                                left: 69*fem,
                                top: 43*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 253*fem,
                                    height: 203*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/tools-2423826640-e1507704253244-1-osE.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroup869zPnQ (PDd2nij6aMFqLbQamD869Z)
                          padding: EdgeInsets.fromLTRB(60*fem, 96*fem, 52*fem, 54.75*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group5WME (7:64)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 127*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // forgotpasswordDWY (6:41)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 40*fem),
                                      constraints: BoxConstraints (
                                        maxWidth: 164*fem,
                                      ),
                                      child: Text(
                                        'Forgot Password?',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 32*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupyqafuPN (PDd2w8ekEhPnGHt31AYQAF)
                                      width: double.infinity,
                                      height: 43*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // group4SeC (6:49)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              width: 278*fem,
                                              height: 43*fem,
                                              child: Align(
                                                // rectangle1yPE (6:50)
                                                alignment: Alignment.topCenter,
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 42*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      color: Color(0x3fffdac0),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // enteremailuXn (6:60)
                                            left: 53*fem,
                                            top: 13*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 74*fem,
                                                height: 17*fem,
                                                child: Text(
                                                  'Enter Email',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2125*ffem/fem,
                                                    color: Color(0xff472913),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // mdiemailoutlinebQc (7:66)
                                            left: 9*fem,
                                            top: 9*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/mdi-email-outline.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group46sA (7:61)
                                margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 32*fem, 85*fem),
                                width: double.infinity,
                                height: 60*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(20*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'SEND',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // backtologinpageAs2 (7:65)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Back to',
                                      ),
                                      TextSpan(
                                        text: ' ',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff934c18),
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Login Page!',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff934c18),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // iphone1441FN (12:2)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 59*fem, 0*fem),
                    width: 390*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group4Wxp (12:3)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                          width: double.infinity,
                          height: 242*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle3T7N (12:4)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 390*fem,
                                    height: 112*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // tools2423826640e15077042532441 (12:5)
                                left: 69*fem,
                                top: 39*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 253*fem,
                                    height: 203*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/tools-2423826640-e1507704253244-1-3Hz.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // registerhereEXS (12:6)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 13*fem),
                          child: Text(
                            'Register Here!',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // craftyourdreamsinwoodjj6 (12:7)
                          'Craft Your Dreams in Wood!!',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff934c18),
                          ),
                        ),
                        Container(
                          // autogroupkd4wGU8 (PDd3sSRbFtWs7UCkuvkd4w)
                          padding: EdgeInsets.fromLTRB(56*fem, 32*fem, 55*fem, 58.75*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group2ytL (12:8)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 28*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                width: 278*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupjdj9U4Q (PDd4BBR2hdZGVQYkYpjdj9)
                                      padding: EdgeInsets.fromLTRB(7*fem, 3*fem, 156*fem, 5*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // mdiuserPBN (12:19)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                            width: 34*fem,
                                            height: 34*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/mdi-user.png',
                                              width: 34*fem,
                                              height: 34*fem,
                                            ),
                                          ),
                                          Container(
                                            // usernamehC4 (12:24)
                                            margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                            child: Text(
                                              'Username',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // line1oVz (12:11)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                                      width: double.infinity,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff934c18),
                                      ),
                                    ),
                                    Container(
                                      // autogroup3apv8oA (PDd4GbRg9TYe4EzTZC3aPV)
                                      padding: EdgeInsets.fromLTRB(8.21*fem, 10*fem, 159*fem, 12.05*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // pheyelighteWc (12:21)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17.21*fem, 0*fem),
                                            width: 28.58*fem,
                                            height: 19.95*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/ph-eye-light-tiC.png',
                                              width: 28.58*fem,
                                              height: 19.95*fem,
                                            ),
                                          ),
                                          Container(
                                            // passwordxGQ (12:13)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.95*fem),
                                            child: Text(
                                              'Password\n',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogrouprpnpTU4 (PDd3Z7cnpwAgaeEypDrpNP)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(6.21*fem, 11*fem, 104*fem, 11.05*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // pheyelightkTA (27:4)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18.21*fem, 0*fem),
                                      width: 28.58*fem,
                                      height: 19.95*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/ph-eye-light.png',
                                        width: 28.58*fem,
                                        height: 19.95*fem,
                                      ),
                                    ),
                                    Container(
                                      // confirmpassword4Cx (27:3)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.95*fem),
                                      child: Text(
                                        'Confirm Password',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff472913),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // line1LgG (15:6)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 32*fem),
                                width: 278*fem,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // autogroupal5qGK2 (PDd3hMt3vN5GKWpnD6AL5q)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                width: 278*fem,
                                height: 42*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // mdiphoneAvC (31:7)
                                      left: 8*fem,
                                      top: 13*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 18*fem,
                                          height: 18*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/mdi-phone.png',
                                            width: 18*fem,
                                            height: 18*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // rectangle2sZi (15:5)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 278*fem,
                                          height: 42*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              color: Color(0x3fffdac0),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // contactnoBaQ (15:8)
                                      left: 53*fem,
                                      top: 15*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 80*fem,
                                          height: 17*fem,
                                          child: Text(
                                            'Contact No.',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2125*ffem/fem,
                                              color: Color(0xff472913),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // line2H7e (15:7)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 34*fem),
                                width: 278*fem,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // group1c9v (12:14)
                                margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 33*fem, 47*fem),
                                width: double.infinity,
                                height: 60*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(20*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'REGISTER',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // haveanaccountsigninGkG (12:18)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'have an account? ',
                                      ),
                                      TextSpan(
                                        text: 'Sign In',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff934c18),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // iphone145oNp (15:2)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                    width: 390*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group478c (15:9)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 45*fem),
                          width: double.infinity,
                          height: 246*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle3dck (15:10)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 390*fem,
                                    height: 112*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // tools2423826640e15077042532441 (15:11)
                                left: 78*fem,
                                top: 43*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 253*fem,
                                    height: 203*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/tools-2423826640-e1507704253244-1-4wi.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // handywood3Ag (15:20)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 7*fem),
                          child: Text(
                            'HANDY WOOD',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // craftyourdreamsinwood9Di (15:21)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 52*fem),
                          child: Text(
                            'Craft Your Dreams in Wood!!',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff934c18),
                            ),
                          ),
                        ),
                        Container(
                          // group6SCp (15:22)
                          margin: EdgeInsets.fromLTRB(95*fem, 0*fem, 90*fem, 200.75*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(30*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupahqd9d2 (PDd54EnHevgjCV1FTNAHqd)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 41*fem),
                                width: double.infinity,
                                height: 67*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(30*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'CUSTOMER',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupjrnwDct (PDd57uLr97kmJebc5JjrNw)
                                width: double.infinity,
                                height: 67*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(30*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'WORKER',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // group86gg (15:72)
                          padding: EdgeInsets.fromLTRB(32*fem, 15.14*fem, 54.47*fem, 7.91*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x3fffdac0),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // vectorc9E (15:74)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 2.72*fem),
                                width: 45*fem,
                                height: 35.2*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-f4L.png',
                                  width: 45*fem,
                                  height: 35.2*fem,
                                ),
                              ),
                              Container(
                                // vectorKZS (15:76)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79.81*fem, 0*fem),
                                width: 42.19*fem,
                                height: 43.95*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-zue.png',
                                  width: 42.19*fem,
                                  height: 43.95*fem,
                                ),
                              ),
                              Container(
                                // vectorSe4 (15:75)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                                width: 40.53*fem,
                                height: 37.71*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector.png',
                                  width: 40.53*fem,
                                  height: 37.71*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // iphone147MW8 (15:32)
                    width: 390*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupewtvgHW (PDd5MPxN7TRMRXjTdTEWTV)
                          width: double.infinity,
                          height: 112*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff472913),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                // gridiconsdropdownosv (30:78)
                                left: 0.0001220703*fem,
                                top: 33*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 99.17*fem,
                                    height: 69.82*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/gridicons-dropdown-yWG.png',
                                      width: 99.17*fem,
                                      height: 69.82*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // handywood7Np (15:58)
                                left: 88*fem,
                                top: 47*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 223*fem,
                                    height: 39*fem,
                                    child: Text(
                                      'HANDY WOOD',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 32*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupyt7qoWY (PDd5Soy1ZHQizNBAdpYT7q)
                          padding: EdgeInsets.fromLTRB(1*fem, 42*fem, 0*fem, 9.75*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // tools2423826640e15077042532441 (15:57)
                                margin: EdgeInsets.fromLTRB(29*fem, 0*fem, 0*fem, 64*fem),
                                width: 258*fem,
                                height: 188*fem,
                                child: Image.asset(
                                  'assets/page-1/images/tools-2423826640-e1507704253244-1-eoi.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                // group7dkU (15:59)
                                margin: EdgeInsets.fromLTRB(77*fem, 0*fem, 66*fem, 184*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(30*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogrouphactk4Q (PDd5a968XfYoChMsshhaCT)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                      width: double.infinity,
                                      height: 72*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                        borderRadius: BorderRadius.circular(30*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'Add Customer',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 24*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupalsxCh6 (PDd5ddzJSwPU834aeZALSX)
                                      width: double.infinity,
                                      height: 75*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff472913),
                                        borderRadius: BorderRadius.circular(30*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'View Customer',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 24*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group8HCk (15:71)
                                padding: EdgeInsets.fromLTRB(32*fem, 15.41*fem, 54.47*fem, 7.64*fem),
                                width: 390*fem,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // vectorB3E (15:70)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 2.72*fem),
                                      width: 45*fem,
                                      height: 35.2*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-4Gp.png',
                                        width: 45*fem,
                                        height: 35.2*fem,
                                      ),
                                    ),
                                    Container(
                                      // vector6AC (15:69)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79.81*fem, 0*fem),
                                      width: 42.19*fem,
                                      height: 43.95*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-FL4.png',
                                        width: 42.19*fem,
                                        height: 43.95*fem,
                                      ),
                                    ),
                                    Container(
                                      // vectoroqJ (15:65)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                                      width: 40.53*fem,
                                      height: 37.71*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-CQY.png',
                                        width: 40.53*fem,
                                        height: 37.71*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupx1cf8Mn (PDcyfyavnaEVpi9bUUx1cf)
              width: 390*fem,
              height: 893*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // addcoustomerdartalldoneFhJ (94:24)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 13.25*fem),
                    child: Text(
                      'addcoustomer.dart all done',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // iphone146AZN (15:23)
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupb4l3JQg (PDcyvPLasxfbU8gYBcb4L3)
                          width: double.infinity,
                          height: 112*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff472913),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                // gridiconsdropdowndxk (30:80)
                                left: 0.0002441406*fem,
                                top: 33*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 99.17*fem,
                                    height: 69.82*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/gridicons-dropdown-Kse.png',
                                      width: 99.17*fem,
                                      height: 69.82*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // customerk1n (15:29)
                                left: 87.5*fem,
                                top: 46*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 148*fem,
                                    height: 39*fem,
                                    child: Text(
                                      'Customer',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 32*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupwkmmRtc (PDcz8xoxjFZg4URJamwKmm)
                          padding: EdgeInsets.fromLTRB(1*fem, 42*fem, 0*fem, 4.75*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // tools2423826640e15077042532441 (15:31)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 78*fem, 67*fem),
                                width: 71*fem,
                                height: 63*fem,
                                child: Image.asset(
                                  'assets/page-1/images/tools-2423826640-e1507704253244-1-PFe.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                // group2Fck (15:78)
                                margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 56*fem, 30*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupim7ykpQ (PDczQHhkwgmHESMLStim7y)
                                      padding: EdgeInsets.fromLTRB(7*fem, 3*fem, 119*fem, 5*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // mdiuserfgU (15:84)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                            width: 34*fem,
                                            height: 34*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/mdi-user-vpQ.png',
                                              width: 34*fem,
                                              height: 34*fem,
                                            ),
                                          ),
                                          Container(
                                            // customernameBui (15:86)
                                            margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                            child: Text(
                                              'Customer name',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // line1uap (15:81)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                                      width: double.infinity,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff934c18),
                                      ),
                                    ),
                                    Container(
                                      // autogroupp6g33h2 (PDczWCha6GSkMkTzzXP6g3)
                                      padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 169*fem, 4*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // ionlocationxJC (15:87)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                            width: 33*fem,
                                            height: 33*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/ion-location.png',
                                              width: 33*fem,
                                              height: 33*fem,
                                            ),
                                          ),
                                          Container(
                                            // addresssAG (15:83)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                            child: Text(
                                              'Address',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group3BRr (15:90)
                                margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 56*fem, 70*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupjvf5t5N (PDcznSjWRkQs4Fo81dJvf5)
                                      padding: EdgeInsets.fromLTRB(12*fem, 10.48*fem, 190*fem, 7*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // vectorNFS (15:102)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0.39*fem),
                                            width: 19*fem,
                                            height: 24.14*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-CQQ.png',
                                              width: 19*fem,
                                              height: 24.14*fem,
                                            ),
                                          ),
                                          Container(
                                            // citygG8 (15:98)
                                            margin: EdgeInsets.fromLTRB(0*fem, 7.52*fem, 0*fem, 0*fem),
                                            child: Text(
                                              'City',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // line1PgL (15:93)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                                      width: double.infinity,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff934c18),
                                      ),
                                    ),
                                    Container(
                                      // autogroupxfmm8P2 (PDcztSZWrni1myrcUoXfMm)
                                      padding: EdgeInsets.fromLTRB(8*fem, 6*fem, 127*fem, 4*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // claritymobilesoliddqa (15:103)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                                            width: 27*fem,
                                            height: 32*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/clarity-mobile-solid.png',
                                              width: 27*fem,
                                              height: 32*fem,
                                            ),
                                          ),
                                          Container(
                                            // phonenumberqwe (15:95)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                            child: Text(
                                              'Phone number',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xff472913),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroup8basjn8 (PDcz28g1Td7hQcuYtA8bas)
                                margin: EdgeInsets.fromLTRB(105*fem, 0*fem, 94*fem, 105*fem),
                                width: double.infinity,
                                height: 52*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff472913),
                                  borderRadius: BorderRadius.circular(20*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'ADD',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // group8cL8 (15:106)
                                padding: EdgeInsets.fromLTRB(32*fem, 15.44*fem, 54.47*fem, 7.61*fem),
                                width: 390*fem,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // vectorWAc (15:108)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 2.72*fem),
                                      width: 45*fem,
                                      height: 35.2*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-gN4.png',
                                        width: 45*fem,
                                        height: 35.2*fem,
                                      ),
                                    ),
                                    Container(
                                      // vectorpBJ (15:110)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79.81*fem, 0*fem),
                                      width: 42.19*fem,
                                      height: 43.95*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-ujn.png',
                                        width: 42.19*fem,
                                        height: 43.95*fem,
                                      ),
                                    ),
                                    Container(
                                      // vector8hn (15:109)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                                      width: 40.53*fem,
                                      height: 37.71*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-Pgc.png',
                                        width: 40.53*fem,
                                        height: 37.71*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}