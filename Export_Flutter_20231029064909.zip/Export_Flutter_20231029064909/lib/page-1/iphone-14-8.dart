import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone148QNC (15:33)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupgkktKEG (PDd8CKDZz3YzCyPTWoGkkT)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 76*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownRHJ (30:82)
                    left: 0.0000610352*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: Image.asset(
                          'assets/page-1/images/gridicons-dropdown-Wtx.png',
                          width: 99.17*fem,
                          height: 69.82*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // customertRn (31:27)
                    left: 87.5*fem,
                    top: 46*fem,
                    child: Align(
                      child: SizedBox(
                        width: 148*fem,
                        height: 39*fem,
                        child: Text(
                          'Customer',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group12kit (19:132)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
              width: 353*fem,
              height: 47*fem,
              child: Image.asset(
                'assets/page-1/images/group-12-ccG.png',
                width: 353*fem,
                height: 47*fem,
              ),
            ),
            Container(
              // autogroupx5njEe4 (PDd8K4XKyDPHGQxPHsX5nj)
              padding: EdgeInsets.fromLTRB(0*fem, 36*fem, 0*fem, 0*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group9m8C (15:121)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 31*fem),
                    padding: EdgeInsets.fromLTRB(31.5*fem, 9*fem, 17*fem, 9*fem),
                    height: 104*fem,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // TWp (19:133)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.05*fem, 34*fem),
                          child: Text(
                            '1)',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupuw4fMMJ (PDd8ZDnQDDyL8berENUw4F)
                          margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 50.45*fem, 13*fem),
                          width: 236*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // namemanisharor (15:120)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                width: double.infinity,
                                child: Text(
                                  'Name: Manisha',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // phone8849631749mA8 (19:130)
                                width: double.infinity,
                                child: Text(
                                  'Phone : 8849631749',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // HuA (19:136)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 47*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Text(
                              '>',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 32*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff934c18),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group9nL8 (19:140)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 267*fem),
                    padding: EdgeInsets.fromLTRB(29.5*fem, 5*fem, 17*fem, 5*fem),
                    height: 104*fem,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // f92 (19:144)
                          margin: EdgeInsets.fromLTRB(0*fem, 15*fem, 14.05*fem, 0*fem),
                          child: Text(
                            '2)',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupkz2xmSx (PDd8oDP5tKL1oxTfKnKz2X)
                          margin: EdgeInsets.fromLTRB(0*fem, 15*fem, 30.45*fem, 17*fem),
                          width: 252*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // nameprernah5i (19:143)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                width: double.infinity,
                                child: Text(
                                  'Name: Prerna',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // phone63555654513DJx (19:142)
                                width: double.infinity,
                                child: Text(
                                  'Phone : 63555654513',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // XaY (19:145)
                          '>',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff934c18),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group85MA (15:113)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(32*fem, 11*fem, 54.47*fem, 12.3*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorySY (15:115)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 2.7*fem),
                          width: 45*fem,
                          height: 35*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-KnY.png',
                            width: 45*fem,
                            height: 35*fem,
                          ),
                        ),
                        Container(
                          // vectorHi8 (15:117)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79.81*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 42.19*fem,
                              height: 43.7*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-wmr.png',
                                width: 42.19*fem,
                                height: 43.7*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // vectorz6k (15:116)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 40.53*fem,
                              height: 37.5*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-FZr.png',
                                width: 40.53*fem,
                                height: 37.5*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}