import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone149mpt (15:34)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupnbcxJpp (PDdQ3Gz1ruFbMwfbu1NBcX)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdowndMJ (30:84)
                    left: 0.0000457764*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: Image.asset(
                          'assets/page-1/images/gridicons-dropdown-7ov.png',
                          width: 99.17*fem,
                          height: 69.82*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodvLQ (31:10)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // manishaZeG (19:162)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
              child: Text(
                'MANISHA',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff934c18),
                ),
              ),
            ),
            Container(
              // autogroupfhkyeQp (PDdQBXFGxLAB6pFQHsfhKy)
              padding: EdgeInsets.fromLTRB(58*fem, 6*fem, 54*fem, 25*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group16a3a (19:217)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group5Uek (19:156)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupyldq2AU (PDdQSGKiBZ417tZehBYLdq)
                                padding: EdgeInsets.fromLTRB(13*fem, 11*fem, 14.58*fem, 14*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // boxworkwYL (19:163)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 168.58*fem, 0*fem),
                                      child: Text(
                                        'Box work',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff472913),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // gridiconsdropdownrfJ (19:153)
                                      margin: EdgeInsets.fromLTRB(0*fem, 4.04*fem, 0*fem, 0*fem),
                                      width: 20.83*fem,
                                      height: 10.21*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/gridicons-dropdown-fnQ.png',
                                        width: 20.83*fem,
                                        height: 10.21*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // line1xTS (19:159)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // group153zg (19:188)
                                padding: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 1*fem),
                                width: double.infinity,
                                height: 50*fem,
                                child: Container(
                                  // autogroupyp3dxLx (PDdQeFyj3deJZLgddXyp3D)
                                  padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 14.58*fem, 15*fem),
                                  width: double.infinity,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0x3fffdac0),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // doorG6k (19:168)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 197.58*fem, 0*fem),
                                        child: Text(
                                          'Door',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff472913),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // gridiconsdropdownmpC (19:164)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.04*fem, 0*fem, 0*fem),
                                        width: 20.83*fem,
                                        height: 10.21*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/gridicons-dropdown-VVA.png',
                                          width: 20.83*fem,
                                          height: 10.21*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // group9Twv (19:189)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroup1hshcZv (PDdQpFh56hUDkt7nQq1hsh)
                                padding: EdgeInsets.fromLTRB(13*fem, 11*fem, 13*fem, 14*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Text(
                                  'Length in cm',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // line1JBr (19:191)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // group15S3A (19:192)
                                width: double.infinity,
                                height: 43*fem,
                                child: Container(
                                  // autogroupnqn7av4 (PDdQyAbtToJGF4GCC3nQn7)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                  padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                                  width: double.infinity,
                                  height: 42*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0x3fffdac0),
                                  ),
                                  child: Text(
                                    'Breadth in cm',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff472913),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // group10EDv (19:201)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupsvefnFS (PDdR7q27yXHFwza8CdsvEf)
                                padding: EdgeInsets.fromLTRB(13*fem, 7*fem, 13*fem, 7*fem),
                                width: double.infinity,
                                height: 42*fem,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Text(
                                  'Material of wood',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // line1rFJ (19:203)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // group15awz (19:204)
                                width: double.infinity,
                                height: 43*fem,
                                child: Container(
                                  // autogroupkh8w9EQ (PDdRV4ujLYALFGcpcPKh8w)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                  padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                                  width: double.infinity,
                                  height: 42*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0x3fffdac0),
                                  ),
                                  child: Text(
                                    'fevicol',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff472913),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16*fem,
                        ),
                        Container(
                          // group11aac (19:209)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupk19dXEx (PDdRdUqNztJHAy6GrLk19d)
                                padding: EdgeInsets.fromLTRB(13*fem, 7*fem, 13*fem, 7*fem),
                                width: double.infinity,
                                height: 42*fem,
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                                child: Text(
                                  'Leminate',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // line1bVi (19:211)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff934c18),
                                ),
                              ),
                              Container(
                                // group15w3n (19:212)
                                width: double.infinity,
                                height: 43*fem,
                                child: Container(
                                  // autogrouph7tztji (PDdRn4RRE9fbHVTNwPH7TZ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                  padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                                  width: double.infinity,
                                  height: 42*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0x3fffdac0),
                                  ),
                                  child: Text(
                                    'Hardware material',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff472913),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group11LLp (19:218)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Container(
                      // autogroupksewUhv (PDdRuDt9dcaJJzkSLBKSEw)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Text(
                        'Total Price',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff472913),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group193N (30:170)
                    margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 34*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'SAVE',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8PTW (19:147)
              padding: EdgeInsets.fromLTRB(33.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vector6si (19:149)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 95.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-SXa.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorpYp (19:151)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 42.3*fem,
                        height: 43.7*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-8fa.png',
                          width: 42.3*fem,
                          height: 43.7*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // vectorv64 (19:150)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-tcQ.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}