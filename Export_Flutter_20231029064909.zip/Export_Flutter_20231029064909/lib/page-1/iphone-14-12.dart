import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1412xDW (15:37)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupi3zsHma (PDdM1XhX6f9DSq8Bzvi3zs)
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownRct (30:90)
                    left: 0*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-Uo2.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodRFW (31:13)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupejmuhD2 (PDdMCwYAyXRjjPdPUUEjMu)
              padding: EdgeInsets.fromLTRB(56*fem, 172*fem, 54*fem, 105*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group2DhA (19:315)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 30*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    width: 278*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup9pxfiP2 (PDdMRbqk7GwVv9JyoB9PxF)
                          padding: EdgeInsets.fromLTRB(7*fem, 3*fem, 134*fem, 5*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x3fffdac0),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // mdiuser2Pi (19:321)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                width: 34*fem,
                                height: 34*fem,
                                child: Image.asset(
                                  'assets/page-1/images/mdi-user-Kma.png',
                                  width: 34*fem,
                                  height: 34*fem,
                                ),
                              ),
                              Container(
                                // workernameKtc (19:323)
                                margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                child: Text(
                                  'Worker Name',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // line1EVn (19:318)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                          width: double.infinity,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff934c18),
                          ),
                        ),
                        Container(
                          // autogroup6wmyAeL (PDdMZM7qVx9z6YDpen6Wmy)
                          padding: EdgeInsets.fromLTRB(5*fem, 5*fem, 169*fem, 4*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x3fffdac0),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ionlocationt4Y (19:324)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                width: 33*fem,
                                height: 33*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ion-location-AJ4.png',
                                  width: 33*fem,
                                  height: 33*fem,
                                ),
                              ),
                              Container(
                                // addressz7a (19:320)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                child: Text(
                                  'Address',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group3Va8 (19:327)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 145*fem),
                    width: 278*fem,
                    height: 43*fem,
                    child: Container(
                      // autogroupuytmEXi (PDdMqRVPGWtjcDfHpnuYTm)
                      padding: EdgeInsets.fromLTRB(8*fem, 6*fem, 127*fem, 4*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // claritymobilesolid9Pn (19:335)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                            width: 27*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/clarity-mobile-solid-ieC.png',
                              width: 27*fem,
                              height: 32*fem,
                            ),
                          ),
                          Container(
                            // phonenumberr3J (19:332)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                            child: Text(
                              'Phone number',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff472913),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogrouplodmZCc (PDdM6hDah7HYERjREfLoDM)
                    margin: EdgeInsets.fromLTRB(50*fem, 0*fem, 40*fem, 0*fem),
                    width: double.infinity,
                    height: 52*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff472913),
                      borderRadius: BorderRadius.circular(20*fem),
                    ),
                    child: Center(
                      child: Text(
                        'ADD',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 24*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8oMr (19:310)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorhy2 (19:312)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-j7v.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorzhE (19:314)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    width: 42.3*fem,
                    height: 43.7*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-5AQ.png',
                      width: 42.3*fem,
                      height: 43.7*fem,
                    ),
                  ),
                  Container(
                    // vectortXi (19:313)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-A4Y.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}