import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1420WQG (19:443)
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroup8abddzg (PDdB7EN7UfDPUER7iG8ABD)
              width: double.infinity,
              height: 112 * fem,
              decoration: BoxDecoration(
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownAji (30:108)
                    left: 0 * fem,
                    top: 33 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17 * fem,
                        height: 69.82 * fem,
                        child: Image.asset(
                          'assets/page-1/images/gridicons-dropdown-W7a.png',
                          width: 99.17 * fem,
                          height: 69.82 * fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // settingseun (21:621)
                    left: 97 * fem,
                    top: 47 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 158 * fem,
                        height: 39 * fem,
                        child: Text(
                          'SETTINGS',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Inter',
                            fontSize: 32 * ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125 * ffem / fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnvjhht4 (PDdBD9MvdEtrbYXnFtnVjH)
              padding:
                  EdgeInsets.fromLTRB(50 * fem, 77 * fem, 61 * fem, 483 * fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // group18R3N (21:625)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 0 * fem, 36 * fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vector8Cg (21:622)
                          margin: EdgeInsets.fromLTRB(
                              0 * fem, 0 * fem, 29 * fem, 1 * fem),
                          width: 34 * fem,
                          height: 38 * fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-E3z.png',
                            width: 34 * fem,
                            height: 38 * fem,
                          ),
                        ),
                        Container(
                          // profilep5W (21:623)
                          margin: EdgeInsets.fromLTRB(
                              0 * fem, 3 * fem, 121 * fem, 0 * fem),
                          child: Text(
                            'Profile',
                            style: SafeGoogleFont(
                              'Inter',
                              fontSize: 24 * ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125 * ffem / fem,
                              color: Color(0xff934c18),
                            ),
                          ),
                        ),
                        Text(
                          // VxL (21:624)
                          '>',
                          style: SafeGoogleFont(
                            'Inter',
                            fontSize: 32 * ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125 * ffem / fem,
                            color: Color(0xff934c18),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    // logoutqWQ (21:635)
                    'Log Out',
                    style: SafeGoogleFont(
                      'Inter',
                      fontSize: 24 * ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125 * ffem / fem,
                      color: Color(0xff934c18),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8AHn (30:138)
              padding: EdgeInsets.fromLTRB(
                  32.08 * fem, 11 * fem, 54.61 * fem, 12.3 * fem),
              width: 391 * fem,
              decoration: BoxDecoration(
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorT1z (30:140)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 96.25 * fem, 2.7 * fem),
                    width: 45.12 * fem,
                    height: 35 * fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-i8G.png',
                      width: 45.12 * fem,
                      height: 35 * fem,
                    ),
                  ),
                  Container(
                    // vectorLLg (30:142)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 80.02 * fem, 0 * fem),
                    width: 42.3 * fem,
                    height: 43.7 * fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-nW4.png',
                      width: 42.3 * fem,
                      height: 43.7 * fem,
                    ),
                  ),
                  Container(
                    // vectorq2Y (30:141)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 0 * fem, 0.2 * fem),
                    width: 40.63 * fem,
                    height: 37.5 * fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-1WG.png',
                      width: 40.63 * fem,
                      height: 37.5 * fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
