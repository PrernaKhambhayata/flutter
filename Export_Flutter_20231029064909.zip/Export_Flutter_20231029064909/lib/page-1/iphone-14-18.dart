import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1418bZz (19:441)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupecjfiuW (PDdCM2dp6DXpv7FMVHeCJF)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownF8k (30:104)
                    left: 0.0000610352*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-rkG.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywood7we (31:19)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // doorDDz (19:554)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
              child: Text(
                'DOOR',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff934c18),
                ),
              ),
            ),
            Container(
              // autogroup9igbji8 (PDdCUrk6mMMzgv72GS9iGb)
              padding: EdgeInsets.fromLTRB(58*fem, 10*fem, 49*fem, 52*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group203Tv (30:6)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 52*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group16k7S (19:555)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupcn1zFK6 (PDdChbssBZVSU5jSWgcn1Z)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 19.92*fem),
                                width: 281*fem,
                                height: 41.89*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // group5Zag (19:556)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 281*fem,
                                        height: 41.89*fem,
                                        child: Align(
                                          // rectangle1J2U (19:557)
                                          alignment: Alignment.topCenter,
                                          child: SizedBox(
                                            width: double.infinity,
                                            height: 40.89*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                color: Color(0x3fffdac0),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // gridiconsdropdownqHJ (19:565)
                                      left: 232.7407226562*fem,
                                      top: 12.8781738281*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 21.06*fem,
                                          height: 9.94*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/gridicons-dropdown-dLU.png',
                                            width: 21.06*fem,
                                            height: 9.94*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // boxworkwLL (19:567)
                                      left: 13*fem,
                                      top: 10*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 61*fem,
                                          height: 17*fem,
                                          child: Text(
                                            'Box work',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2125*ffem/fem,
                                              color: Color(0xff472913),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group9Qzc (19:568)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.55*fem),
                                width: 281*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroup3px9wzY (PDdD1G37LqvAFc8cE33PX9)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.58*fem),
                                      width: double.infinity,
                                      height: 41.89*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // rectangle1UUg (19:569)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 281*fem,
                                                height: 40.89*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    color: Color(0x3fffdac0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // lengthincmo1A (19:582)
                                            left: 13.1402587891*fem,
                                            top: 10.7098388672*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 86*fem,
                                                height: 17*fem,
                                                child: Text(
                                                  'Length in cm',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2125*ffem/fem,
                                                    color: Color(0xff472913),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // group15VPn (19:571)
                                      width: double.infinity,
                                      height: 41.89*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // rectangle2E6U (19:572)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 281*fem,
                                                height: 40.89*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    color: Color(0x3fffdac0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // breadthincm9DS (19:574)
                                            left: 13.1402587891*fem,
                                            top: 9.7362060547*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 92*fem,
                                                height: 17*fem,
                                                child: Text(
                                                  'Breadth in cm',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2125*ffem/fem,
                                                    color: Color(0xff472913),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group10SyE (19:575)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.55*fem),
                                width: 281*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroup4rqjBfv (PDdDE6153WfHdBhrPq4rQj)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.58*fem),
                                      width: double.infinity,
                                      height: 41.89*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // rectangle1WTJ (19:576)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 281*fem,
                                                height: 40.89*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    color: Color(0x3fffdac0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // materialofwoodRqA (19:583)
                                            left: 13.1402587891*fem,
                                            top: 6.8153076172*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 112*fem,
                                                height: 17*fem,
                                                child: Text(
                                                  'Material of wood',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2125*ffem/fem,
                                                    color: Color(0xff472913),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // group15KvY (19:578)
                                      width: double.infinity,
                                      height: 41.89*fem,
                                      child: Container(
                                        // autogroupbxcsgm6 (PDdDPVu47NBRfqXDiKBxCs)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                        padding: EdgeInsets.fromLTRB(13.14*fem, 9.74*fem, 13.14*fem, 14.16*fem),
                                        width: double.infinity,
                                        height: 40.89*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0x3fffdac0),
                                        ),
                                        child: Text(
                                          'fevicol',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff472913),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // group11ixg (19:584)
                                width: 281*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupvtvk52Y (PDdDXkAKCo61Qi727BVTvK)
                                      padding: EdgeInsets.fromLTRB(13.14*fem, 6.82*fem, 13.14*fem, 6.82*fem),
                                      width: double.infinity,
                                      height: 40.89*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0x3fffdac0),
                                      ),
                                      child: Text(
                                        'Leminate',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff472913),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // line1keU (19:586)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.58*fem),
                                      width: double.infinity,
                                      height: 1*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff934c18),
                                      ),
                                    ),
                                    Container(
                                      // group15h3v (19:587)
                                      width: double.infinity,
                                      height: 41.89*fem,
                                      child: Container(
                                        // autogroupsak3qvp (PDdDfVSQbUJVb71rxnSak3)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                        padding: EdgeInsets.fromLTRB(13.14*fem, 9.74*fem, 13.14*fem, 14.16*fem),
                                        width: double.infinity,
                                        height: 40.89*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0x3fffdac0),
                                        ),
                                        child: Text(
                                          'Hardware material',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff472913),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // group11tu6 (19:592)
                          margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 3*fem, 0*fem),
                          width: double.infinity,
                          height: 43*fem,
                          child: Container(
                            // autogroupdud9dLt (PDdEAtm5mTUU2qhXqrdUD9)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                            width: double.infinity,
                            height: 42*fem,
                            decoration: BoxDecoration (
                              color: Color(0x3fffdac0),
                            ),
                            child: Text(
                              'Total Price',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff472913),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group1hbe (30:7)
                    margin: EdgeInsets.fromLTRB(24*fem, 0*fem, 45*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'SAVE',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8wF6 (19:548)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorFWg (19:550)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-ywv.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorkyE (19:552)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 42.3*fem,
                        height: 43.7*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-utL.png',
                          width: 42.3*fem,
                          height: 43.7*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // vectorFQC (19:551)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-afa.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}