import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1413kak (15:38)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroups3rdHKn (PDdKjEVyyLNJCZwAXaS3RD)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 76*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownbLU (30:92)
                    left: 0*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-7VJ.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodGhW (31:14)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group12LSU (19:412)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
              width: 353*fem,
              height: 47*fem,
              child: Image.asset(
                'assets/page-1/images/group-12-P44.png',
                width: 353*fem,
                height: 47*fem,
              ),
            ),
            Container(
              // autogroupgmwhSEc (PDdKrp7go6MRC8xMY6GMwh)
              padding: EdgeInsets.fromLTRB(0*fem, 36*fem, 0*fem, 267*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group9mGt (19:423)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 31*fem),
                    padding: EdgeInsets.fromLTRB(31.5*fem, 9*fem, 17*fem, 9*fem),
                    height: 104*fem,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rZE (19:427)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.05*fem, 34*fem),
                          child: Text(
                            '1)',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupxrnfkuW (PDdL399oyze4mLAp1ZXrNf)
                          margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 50.45*fem, 13*fem),
                          width: 236*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // namemanisha5Rz (19:426)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                width: double.infinity,
                                child: Text(
                                  'Name: Manisha',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // phone8849631749Bjv (19:425)
                                width: double.infinity,
                                child: Text(
                                  'Phone : 8849631749',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // iUx (19:428)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 47*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Text(
                              '>',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 32*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff934c18),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group9Qsa (19:432)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(29.5*fem, 5*fem, 17*fem, 5*fem),
                    height: 104*fem,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // tGx (19:436)
                          margin: EdgeInsets.fromLTRB(0*fem, 15*fem, 12.05*fem, 0*fem),
                          child: Text(
                            '2)',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff472913),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupqfb1oui (PDdLLdefaMqRN2gKspqfb1)
                          margin: EdgeInsets.fromLTRB(0*fem, 15*fem, 32.45*fem, 17*fem),
                          width: 252*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // nameprernaL8x (19:435)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                width: double.infinity,
                                child: Text(
                                  'Name: Prerna',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // phone63555654513qbW (19:434)
                                width: double.infinity,
                                child: Text(
                                  'Phone : 63555654513',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // weY (19:437)
                          '>',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff934c18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8sHJ (19:407)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorxZe (19:409)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-5xU.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorU2C (19:411)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    width: 42.3*fem,
                    height: 43.7*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-UXr.png',
                      width: 42.3*fem,
                      height: 43.7*fem,
                    ),
                  ),
                  Container(
                    // vectormmz (19:410)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-AFa.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}