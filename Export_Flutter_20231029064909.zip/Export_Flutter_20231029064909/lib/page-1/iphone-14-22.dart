import 'package:flutter/material.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Text(
        'Your content goes here',
        style: TextStyle(
          fontSize: 24.0,
          color: Colors.black,
        ),
      ),
    );
  }
}
