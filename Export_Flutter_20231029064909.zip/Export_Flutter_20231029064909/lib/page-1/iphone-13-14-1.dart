import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13141fZA (160:73)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupb9abQWk (PDdUyPGHdAXUS5hp13B9Ab)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 86*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupkq9uX5a (PDdUpyLdxpPXWPEMm5kq9u)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 28*fem),
                    width: 389*fem,
                    height: 112*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff472913),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // gridiconsdropdownRRr (160:75)
                          left: 0*fem,
                          top: 33*fem,
                          child: Align(
                            child: SizedBox(
                              width: 98.91*fem,
                              height: 69.82*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Image.asset(
                                  'assets/page-1/images/gridicons-dropdown-H4L.png',
                                  width: 98.91*fem,
                                  height: 69.82*fem,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // handywood6nt (160:77)
                          left: 88*fem,
                          top: 48*fem,
                          child: Align(
                            child: SizedBox(
                              width: 223*fem,
                              height: 39*fem,
                              child: Text(
                                'HANDY WOOD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // manisha19A (160:78)
                    margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 54*fem),
                    child: Text(
                      'MANISHA',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff934c18),
                      ),
                    ),
                  ),
                  Container(
                    // group21j5A (160:87)
                    margin: EdgeInsets.fromLTRB(69.82*fem, 0*fem, 42.89*fem, 30.87*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 1*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Container(
                      // autogroupsnz93be (PDdVFHySpp2rkwFdKxsNZ9)
                      padding: EdgeInsets.fromLTRB(13.18*fem, 10.06*fem, 14.55*fem, 14.94*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // startingdateLqe (160:92)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141.79*fem, 0*fem),
                            child: Text(
                              'Starting date',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff472913),
                              ),
                            ),
                          ),
                          Container(
                            // gridiconsdropdownTQU (160:89)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.09*fem),
                            width: 20.78*fem,
                            height: 10.21*fem,
                            child: Image.asset(
                              'assets/page-1/images/gridicons-dropdown-cfz.png',
                              width: 20.78*fem,
                              height: 10.21*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // group22YRv (160:93)
                    margin: EdgeInsets.fromLTRB(69.61*fem, 0*fem, 43.1*fem, 31.72*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 1*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Container(
                      // autogroup1djyTon (PDdVUHbo6Q1MKLiXLr1djy)
                      padding: EdgeInsets.fromLTRB(13.18*fem, 10.06*fem, 14.55*fem, 14.94*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // endingdateyn8 (160:98)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 149.79*fem, 0*fem),
                            child: Text(
                              'Ending date',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff472913),
                              ),
                            ),
                          ),
                          Container(
                            // gridiconsdropdowngAk (160:95)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.09*fem),
                            width: 20.78*fem,
                            height: 10.21*fem,
                            child: Image.asset(
                              'assets/page-1/images/gridicons-dropdown-VHr.png',
                              width: 20.78*fem,
                              height: 10.21*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // group23y9r (160:99)
                    margin: EdgeInsets.fromLTRB(69.82*fem, 0*fem, 42.89*fem, 28.73*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Container(
                      // autogroupqxkzJT2 (PDdVehU7ZkugUwsojrqXKZ)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      padding: EdgeInsets.fromLTRB(12.97*fem, 10*fem, 12.97*fem, 15*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Text(
                        'Total Time',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff472913),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group249yS (160:103)
                    margin: EdgeInsets.fromLTRB(69.82*fem, 0*fem, 42.89*fem, 134.68*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Container(
                      // autogroupeezftg8 (PDdVnMv1fyWV4vqpfvEEzf)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      padding: EdgeInsets.fromLTRB(12.97*fem, 10*fem, 12.97*fem, 15*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0x3fffdac0),
                      ),
                      child: Text(
                        'Total Price',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff472913),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group20N5W (160:84)
                    margin: EdgeInsets.fromLTRB(95.75*fem, 0*fem, 96.75*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Generate bill',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              // group19D68 (160:79)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(32*fem, 11*fem, 54.47*fem, 12.3*fem),
                width: double.infinity,
                decoration: BoxDecoration (
                  color: Color(0x3fffdac0),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // vectoruje (160:81)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96*fem, 2.7*fem),
                      width: 45*fem,
                      height: 35*fem,
                      child: Image.asset(
                        'assets/page-1/images/vector-6aU.png',
                        width: 45*fem,
                        height: 35*fem,
                      ),
                    ),
                    Container(
                      // vectorRhz (160:83)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 79.81*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 42.19*fem,
                          height: 43.7*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-gja.png',
                            width: 42.19*fem,
                            height: 43.7*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // vectorWzL (160:82)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 40.53*fem,
                          height: 37.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-1nG.png',
                            width: 40.53*fem,
                            height: 37.5*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}