import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1415DTE (19:438)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroup4jjdXip (PDdHMYxPtoQtS8PMXA4JjD)
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownrWC (30:96)
                    left: 0.0000610352*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-YwJ.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodw1r (31:16)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle4Bwn (160:35)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 390*fem,
                        height: 112*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff472913),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // gridiconsdropdownuMz (160:36)
                    left: 0.0000610352*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-SB2.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodPY4 (160:38)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupwp8pgXA (PDdHt35bkkajbEMmQJWP8P)
              padding: EdgeInsets.fromLTRB(70*fem, 27*fem, 42*fem, 86*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouprbydPAg (PDdHXDLxp2n5G23CcGrbyD)
                    margin: EdgeInsets.fromLTRB(77*fem, 0*fem, 108*fem, 55*fem),
                    width: double.infinity,
                    height: 25*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // manishaVzQ (19:482)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 93*fem,
                              height: 25*fem,
                              child: Text(
                                'MANISHA',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff934c18),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // manishabGk (160:39)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 93*fem,
                              height: 25*fem,
                              child: Text(
                                'MANISHA',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff934c18),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group15sEG (19:494)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangle2bg4 (19:495)
                          left: 0*fem,
                          top: 7*fem,
                          child: Align(
                            child: SizedBox(
                              width: 278*fem,
                              height: 42*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // gridiconsdropdowngxQ (19:496)
                          left: 242.5833435059*fem,
                          top: 20.4166259766*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20.83*fem,
                              height: 10.21*fem,
                              child: Image.asset(
                                'assets/page-1/images/gridicons-dropdown-4Dv.png',
                                width: 20.83*fem,
                                height: 10.21*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // datemyr (19:499)
                          left: 13*fem,
                          top: 17*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 17*fem,
                              child: Text(
                                'Date',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group15g5E (160:49)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 1*fem),
                            width: 278*fem,
                            height: 50*fem,
                            child: Container(
                              // autogroupswzdnPA (PDdJGh6WwZvQyXUWWJSwZD)
                              padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 14.58*fem, 15*fem),
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0x3fffdac0),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // date5dA (160:54)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 197.58*fem, 0*fem),
                                    child: Text(
                                      'Date',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff472913),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // gridiconsdropdownb5i (160:51)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0.04*fem, 0*fem, 0*fem),
                                    width: 20.83*fem,
                                    height: 10.21*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/gridicons-dropdown-vcg.png',
                                      width: 20.83*fem,
                                      height: 10.21*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group11JF2 (19:500)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangle1pz4 (19:501)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 278*fem,
                              height: 42*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // totaltimekcp (19:502)
                          left: 13*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 17*fem,
                              child: Text(
                                'Total Time',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group16SkY (160:55)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 278*fem,
                            height: 43*fem,
                            child: Container(
                              // autogroupvznpnZW (PDdJWGYECNCggpZByzVznP)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                              padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                              width: double.infinity,
                              height: 42*fem,
                              decoration: BoxDecoration (
                                color: Color(0x3fffdac0),
                              ),
                              child: Text(
                                'Total Time',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group12qXn (19:504)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 224*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangle1AKA (19:505)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 278*fem,
                              height: 42*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0x3fffdac0),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // totalprice5S8 (19:506)
                          left: 13*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 17*fem,
                              child: Text(
                                'Total Price',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group17NRE (160:59)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 278*fem,
                            height: 43*fem,
                            child: Container(
                              // autogroup15oqWXS (PDdJgvu8X6x4dfYx9e15oq)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                              padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 13*fem, 15*fem),
                              width: double.infinity,
                              height: 42*fem,
                              decoration: BoxDecoration (
                                color: Color(0x3fffdac0),
                              ),
                              child: Text(
                                'Total Price',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group1BNg (19:488)
                    margin: EdgeInsets.fromLTRB(26*fem, 0*fem, 54*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // save4SU (19:490)
                              left: 68.5*fem,
                              top: 16*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 61*fem,
                                  height: 30*fem,
                                  child: Text(
                                    'SAVE',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group149ip (160:45)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 198*fem,
                                  height: 60*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff472913),
                                    borderRadius: BorderRadius.circular(20*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'SAVE',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 24*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupvx35ap8 (PDdHcJ2q82JiTChbvTvx35)
              width: 391*fem,
              height: 67*fem,
              child: Image.asset(
                'assets/page-1/images/auto-group-vx35.png',
                width: 391*fem,
                height: 67*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}