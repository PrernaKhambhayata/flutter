import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1410gPa (15:35)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupxdvmoUC (PDdP1oh7FFzBjAjekWXDVM)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 46*fem),
              width: double.infinity,
              height: 112*fem,
              decoration: BoxDecoration (
                color: Color(0xff472913),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // gridiconsdropdownun8 (30:86)
                    left: 0.0000610352*fem,
                    top: 33*fem,
                    child: Align(
                      child: SizedBox(
                        width: 99.17*fem,
                        height: 69.82*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/gridicons-dropdown-fwN.png',
                            width: 99.17*fem,
                            height: 69.82*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // handywoodAxx (31:11)
                    left: 88*fem,
                    top: 47*fem,
                    child: Align(
                      child: SizedBox(
                        width: 223*fem,
                        height: 39*fem,
                        child: Text(
                          'HANDY WOOD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // namemanishaTx4 (19:241)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
              width: double.infinity,
              child: Text(
                'Name: Manisha',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 24*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff472913),
                ),
              ),
            ),
            Container(
              // phone8849631749ArU (19:242)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
              width: double.infinity,
              child: Text(
                'Phone : 8849631749',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 24*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff472913),
                ),
              ),
            ),
            Container(
              // addressbhujGec (19:243)
              width: double.infinity,
              child: Text(
                'Address : Bhuj',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 24*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff472913),
                ),
              ),
            ),
            Container(
              // autogrouphvuzoPe (PDdP9tHymmfQHDRoJHhvuZ)
              padding: EdgeInsets.fromLTRB(0*fem, 48*fem, 0*fem, 86*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group9KMz (19:258)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 179*fem),
                    padding: EdgeInsets.fromLTRB(5*fem, 7*fem, 141*fem, 8*fem),
                    width: double.infinity,
                    height: 138*fem,
                    decoration: BoxDecoration (
                      color: Color(0x3fffdac0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // steeldoorforhomesrk1893feet1Ps (19:264)
                          width: 116*fem,
                          height: 123*fem,
                          child: Image.asset(
                            'assets/page-1/images/steel-door-for-home-srk-1893feet-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // autogroupcaz7KWQ (PDdPPNuVk7KzQ6ZerSCaz7)
                          margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 0*fem, 19*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // totalprice120003SQ (19:265)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                child: Text(
                                  'Total Price : 12,000',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // materialwoodYe4 (19:266)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                child: Text(
                                  'Material : Wood',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Container(
                                // length3mqt4 (19:267)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                child: Text(
                                  'Length : 3m',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff472913),
                                  ),
                                ),
                              ),
                              Text(
                                // breadth1mN7J (19:268)
                                'Breadth : 1m',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff472913),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group1hfN (19:244)
                    margin: EdgeInsets.fromLTRB(92*fem, 0*fem, 84*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 60*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff472913),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Center(
                          child: Text(
                            'ADD ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group8wZi (19:235)
              padding: EdgeInsets.fromLTRB(32.08*fem, 11*fem, 54.61*fem, 12.3*fem),
              width: 391*fem,
              decoration: BoxDecoration (
                color: Color(0x3fffdac0),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // vectorT2G (19:237)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 96.25*fem, 2.7*fem),
                    width: 45.12*fem,
                    height: 35*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-sLc.png',
                      width: 45.12*fem,
                      height: 35*fem,
                    ),
                  ),
                  Container(
                    // vectorZ5J (19:239)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.02*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 42.3*fem,
                        height: 43.7*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-qax.png',
                          width: 42.3*fem,
                          height: 43.7*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // vector3FN (19:238)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40.63*fem,
                        height: 37.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-ixg.png',
                          width: 40.63*fem,
                          height: 37.5*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}